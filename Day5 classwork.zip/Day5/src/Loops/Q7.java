package Loops;

public class Q7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
           int a=229;
           while(a<521)
           {
        	   System.out.println(a);
        	   a+=2;
           }
	}

}
