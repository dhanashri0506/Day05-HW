package Loops;

public class Q24 {

		// TODO Auto-generated method stub
		public static void main(String[] args) {
			 
			for (int num=1;num<=20;num++)
			{
				System.out.println("square root of :"+(num*num));
		    }
	}
}


