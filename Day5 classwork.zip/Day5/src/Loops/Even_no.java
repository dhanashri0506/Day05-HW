package Loops;

public class Even_no {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		  int num=2;
		  
		  while(num<50)
		  {
				  System.out.println(num);
				   num+=2;
		  }
  }
}
