package Loops;

public class Alternate_num {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	      int num=1;
	    		  while(num<50)
	    		  {
	    			 System.out.println("The Alternate numbers between 1 to 50:" + num);
	    			 num+=2;
	    		  }
	}

}
