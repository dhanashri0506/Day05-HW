package Loops;

import java.util.Scanner;

public class Q22 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner Sc= new Scanner (System.in);
		
		for (int i=101;i<=110;i+=2)
		{
			System.out.println(i);
		}	
	}	
}
