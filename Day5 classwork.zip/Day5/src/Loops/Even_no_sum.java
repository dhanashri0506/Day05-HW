package Loops;

public class Even_no_sum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	      int num=2;
	      int sum=0;
	    		  while(num<=10)
	    		  {
	 	    			    sum+=num;
	 	    			    num+=2;
	    		  }
	    		  System.out.println("total sum of even num:" +sum);
	}

}
