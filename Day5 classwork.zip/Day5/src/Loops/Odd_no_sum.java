package Loops;

public class Odd_no_sum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=1;
	      int sum=0;
	    		  while(num<10)
	    		  {
	 	    			    sum+=num;
	 	    			    num+=2;
	    		  }
	    		  System.out.println("total sum of odd num:" +sum);
	}

}
