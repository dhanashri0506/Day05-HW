package Loops;

public class Q15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=1;
	      int sum=0;
	    		do
	    		  {
	 	    			    sum+=num;
	 	    			    num+=2;
	    		  }
	    		  while(num<10);
	    		  System.out.println("total sum of odd num:" +sum);
	}


}
