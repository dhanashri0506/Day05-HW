package Loops;

import java.util.Scanner;

public class Q17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner Sc= new Scanner (System.in);
		 
		System.out.println("Enter the number");
		int b=Sc.nextInt();
		 do{
			 for (int a=1;a<=10;a++)
			 {
				 System.out.println(b+ "*" + a +"="+(a*b));
			 }
	     }
		 while(b<=0);
		
	}

}
