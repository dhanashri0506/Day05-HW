package Loops;

public class Q18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int a=229;
         do{
      	   System.out.println(a);
      	   a+=2;
         }
         while(a<521);
	}

}
