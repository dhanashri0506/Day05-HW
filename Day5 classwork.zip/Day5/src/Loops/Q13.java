package Loops;

public class Q13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int num=1;
	             do
	    		  {
	            	 System.out.println("odd numbers:" +num);
	 	    			    num+=2;
	    		  }
	             while(num<=50);
	    		 
	}
}
