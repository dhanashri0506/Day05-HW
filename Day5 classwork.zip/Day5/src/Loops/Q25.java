package Loops;

//import java.util.Scanner;

public class Q25 {
	public static void main(String[] args) {
	 
	int num=5;
	for (int a=1;a<=10;a++)
	{
		System.out.println(num+ "*" + a +"="+(a*num));
    }
	}
}