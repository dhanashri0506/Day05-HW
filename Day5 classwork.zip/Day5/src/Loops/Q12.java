package Loops;

public class Q12 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int num=2;
	             do
	    		  {
	            	 System.out.println("Even numbers:" +num);
	 	    			    num+=2;
	    		  }
	             while(num<=50);
	    		 
	}

}
