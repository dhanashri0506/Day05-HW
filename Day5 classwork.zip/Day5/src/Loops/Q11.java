package Loops;

public class Q11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=1;
		do
		  {
			 System.out.println("Alternate numbers between 1 to 50:" + num);
			 num+=2;
		  }
		  while(num<50);
		
    }
}


