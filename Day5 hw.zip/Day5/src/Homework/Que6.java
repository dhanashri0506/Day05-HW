package Homework;

public class Que6 {

	public static void main(String[] args) {
		//prime number

	}

}
