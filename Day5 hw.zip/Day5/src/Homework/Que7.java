package Homework;

public class Que7 {

	public static void main(String[] args) {
		System.out.println("Squares of the numbers from 1 to 20 : ");
		for(int i=1; i<=20;i++) {
			int square = i* i;
			System.out.println("Sauare of " + i + "is: " + square);
		}

	}

}
