package Homework;

public class Que1 {

	public static void main(String[] args) {
		int sum=0;
		int i = 1;
		while(i<=10) {
			i++;
		}
		System.out.println("The sum of numbers from 1 to 1- is: "+sum);

	}

}
